/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */


/**
 *
 * @author jeyhl
 */

import org.junit.*;
import static org.junit.Assert.*;
import product.Inventory;
import product.Magazine;
import product.Product;
import product.Book;   // <-- use your own Book class

public class InventoryTest {
    private Inventory inv;

    @Before
    public void setUp() {
        inv = new Inventory(2, 2);
        inv.addProduct(new Book("B01", "Test Book", 100.0, 5, "Auth", 200));
        inv.addProduct(new Magazine("M01", "News Mag", 20.0, 10, 12));
    }

    @Test
    public void testAddProductAndFind() {
        assertEquals(2, inv.getSize());
        Product p = inv.getProductAt(0);
        assertEquals("B01", p.getId());
    }

    @Test
    public void testSellProductUpdatesStockAndSales() {
        boolean sold = inv.sellProduct("B01", 2, 0);
        assertTrue(sold);
        Product p = inv.getProductAt(0);
        assertEquals(3, p.getStock()); // 5 - 2 = 3
    }

    @Test
    public void testCannotSellMoreThanStock() {
        boolean sold = inv.sellProduct("B01", 100, 0);
        assertFalse(sold);
        assertEquals(5, inv.getProductAt(0).getStock());
    }

    @Test
    public void testRestock() {
        inv.restockProduct("B01", 10);
        assertEquals(15, inv.getProductAt(0).getStock());
    }

    @Test
    public void testTotalRevenueCalculation() {
        inv.sellProduct("B01", 1, 0); // 100
        inv.sellProduct("M01", 2, 1); // 40
        double rev = inv.getTotalRevenue();
        assertEquals(140.0, rev, 0.001);
    }
}
