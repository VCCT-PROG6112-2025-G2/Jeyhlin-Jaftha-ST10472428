/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package product;

/**
 *
 * @author jeyhl
 */
// Book.java
public class Book extends Product {
    private String author;
    private int pages;

    public Book(String id, String title, double price, int stock, String author, int pages) {
        super(id, title, price, stock);
        this.author = author;
        this.pages = pages;
    }

    public String getAuthor() { return author; }
    public int getPages() { return pages; }

    @Override
    public String getTypeName() {
        return "Book";
    }

    @Override
    public String toString() {
        return getId() + " - " + getTitle() + " by " + author;
    }
}
