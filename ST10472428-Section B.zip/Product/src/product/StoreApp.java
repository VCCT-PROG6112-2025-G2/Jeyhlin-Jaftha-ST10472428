/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package product;

/**
 *
 * @author jeyhl
 */
// StoreApp.java
public class StoreApp {
    public static void main(String[] args) {
        // Track 3 months initially, capacity for 4 products
        Inventory inv = new Inventory(4, 3);

        // add several products (use constructors -> inheritance)
        inv.addProduct(new Book("B001", "Java Basics", 199.99, 10, "A. Developer", 300));
        inv.addProduct(new Book("B002", "Algorithms", 299.50, 5, "C. Algo", 420));
        inv.addProduct(new Magazine("M001", "Tech Monthly", 49.99, 20, 78));
        inv.addProduct(new Magazine("M002", "Gamer's Guide", 39.95, 8, 44));

        // simulate sales across 3 months (use loops and arrays)
        // Month 1
        inv.sellProduct("B001", 2, 0);
        inv.sellProduct("M001", 5, 0);
        inv.sellProduct("B002", 1, 0);

        // Month 2
        inv.sellProduct("B001", 3, 1);
        inv.sellProduct("M002", 2, 1);
        inv.sellProduct("M001", 4, 1);

        // Month 3
        inv.sellProduct("B002", 2, 2);
        inv.sellProduct("M001", 3, 2);
        inv.restockProduct("B002", 5); // restock example

        // Print final report to console
        inv.printReport();
    }
}
