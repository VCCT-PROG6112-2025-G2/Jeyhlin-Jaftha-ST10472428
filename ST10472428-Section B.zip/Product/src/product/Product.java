/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package product;

/**
 *
 * @author jeyhl
 */
    
public abstract class Product {
    private String id;
    private String title;
    private double price;
    private int stock;

    public Product(String id, String title, double price, int stock) {
        this.id = id;
        this.title = title;
        this.price = price;
        this.stock = stock;
    }

    // Information hiding: getters/setters
    public String getId() { return id; }
    public String getTitle() { return title; }
    public double getPrice() { return price; }
    public int getStock() { return stock; }

    public void setPrice(double price) { this.price = price; }
    public void setStock(int stock) { this.stock = stock; }

    // reduce stock when selling; return true if successful
    public boolean sellUnits(int qty) {
        if (qty <= 0 || qty > stock) return false;
        stock -= qty;
        return true;
    }

    public void restock(int qty) {
        if (qty > 0) stock += qty;
    }

    // each subclass implements its own report line details
    public abstract String getTypeName();

    public String toReportString() {
        return String.format("%-6s | %-25s | %-10s | %6.2f | %4d",
                id, title, getTypeName(), price, stock);
    }
}
