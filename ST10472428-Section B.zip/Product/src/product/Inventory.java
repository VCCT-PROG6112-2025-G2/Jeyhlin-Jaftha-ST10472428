/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package product;

/**
 *
 * @author jeyhl
 */

import java.util.Arrays;

public class Inventory {
    private Product[] products;      // array storing products
    private int size;                // number of products currently stored
    private double[] priceHistory;   // demo of another array (parallel)
    private int[][] monthlySales;    // advanced 2D array: months x products

    public Inventory(int initialCapacity, int monthsToTrack) {
        if (initialCapacity < 2) initialCapacity = 2;
        products = new Product[initialCapacity];
        priceHistory = new double[initialCapacity];
        size = 0;
        monthlySales = new int[monthsToTrack][initialCapacity];
    }

    // add product (resizes arrays when full)
    public void addProduct(Product p) {
        ensureCapacity();
        products[size] = p;
        priceHistory[size] = p.getPrice();
        // clear monthlySales columns for this new product
        for (int m = 0; m < monthlySales.length; m++) {
            monthlySales[m][size] = 0;
        }
        size++;
    }

    // ensure arrays are large enough (array resizing)
    private void ensureCapacity() {
        if (size < products.length) return;
        int newCap = products.length * 2;
        products = Arrays.copyOf(products, newCap);
        priceHistory = Arrays.copyOf(priceHistory, newCap);
        // expand monthlySales columns
        int months = monthlySales.length;
        int[][] newMonthly = new int[months][newCap];
        for (int m = 0; m < months; m++) {
            System.arraycopy(monthlySales[m], 0, newMonthly[m], 0, monthlySales[m].length);
        }
        monthlySales = newMonthly;
    }

    // find product index by id
    public int findIndexById(String id) {
        for (int i = 0; i < size; i++) {
            if (products[i].getId().equalsIgnoreCase(id)) return i;
        }
        return -1;
    }

    // sell product: update stock and monthly sales
    // monthIndex is 0-based (0 to months-1)
    public boolean sellProduct(String id, int qty, int monthIndex) {
        int idx = findIndexById(id);
        if (idx == -1 || qty <= 0 || monthIndex < 0 || monthIndex >= monthlySales.length) return false;
        Product p = products[idx];
        boolean sold = p.sellUnits(qty);
        if (sold) monthlySales[monthIndex][idx] += qty;
        return sold;
    }

    public boolean restockProduct(String id, int qty) {
        int idx = findIndexById(id);
        if (idx == -1 || qty <= 0) return false;
        products[idx].restock(qty);
        return true;
    }

    // returns total sales revenue for all months and products
    public double getTotalRevenue() {
        double total = 0.0;
        for (int m = 0; m < monthlySales.length; m++) {
            for (int p = 0; p < size; p++) {
                total += monthlySales[m][p] * products[p].getPrice();
            }
        }
        return total;
    }

    // total units sold for a product across all months
    public int totalUnitsSoldForProduct(int productIndex) {
        int sum = 0;
        for (int m = 0; m < monthlySales.length; m++) sum += monthlySales[m][productIndex];
        return sum;
    }

    // print a neat inventory & sales report to console
    public void printReport() {
        System.out.println("===== SIMPLE BOOKSTORE REPORT =====");
        System.out.printf("Products tracked: %d  | Months tracked: %d%n", size, monthlySales.length);
        System.out.println("ID     | Title                     | Type       |   Price | Stk ");
        System.out.println("----------------------------------------------------------------------");
        for (int i = 0; i < size; i++) {
            System.out.println(products[i].toReportString());
        }
        System.out.println("----------------------------------------------------------------------");
        System.out.println("Monthly Sales Summary (units sold)");
        System.out.print("Month\\Prod");
        for (int p = 0; p < size; p++) System.out.printf(" | %s", products[p].getId());
        System.out.println();
        for (int m = 0; m < monthlySales.length; m++) {
            System.out.printf("%5d    ", m+1);
            for (int p = 0; p < size; p++) {
                System.out.printf(" | %3d", monthlySales[m][p]);
            }
            System.out.println();
        }
        System.out.println("----------------------------------------------------------------------");
        System.out.printf("Total Revenue: R%.2f%n", getTotalRevenue());
        // Top-selling product
        int topIdx = -1; int topUnits = -1;
        for (int p = 0; p < size; p++) {
            int sold = totalUnitsSoldForProduct(p);
            if (sold > topUnits) { topUnits = sold; topIdx = p; }
        }
        if (topIdx >= 0) {
            System.out.printf("Top selling product: %s (%d units)%n", products[topIdx].getTitle(), topUnits);
        } else {
            System.out.println("No sales yet.");
        }
        System.out.println("====================================");
    }

    // getter for testing
    public Product getProductAt(int idx) { 
        if (idx < 0 || idx >= size) return null;
        return products[idx];
    }

    public int getSize() { return size; }
}
