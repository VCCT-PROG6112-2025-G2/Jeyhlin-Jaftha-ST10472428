/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package product;

/**
 *
 * @author jeyhl
 */
// Magazine.java
public class Magazine extends Product {
    private int issueNumber;

    public Magazine(String id, String title, double price, int stock, int issueNumber) {
        super(id, title, price, stock);
        this.issueNumber = issueNumber;
    }

    public int getIssueNumber() { return issueNumber; }

    @Override
    public String getTypeName() {
        return "Magazine";
    }

    @Override
    public String toString() {
        return getId() + " - " + getTitle() + " (Issue " + issueNumber + ")";
    }
}
